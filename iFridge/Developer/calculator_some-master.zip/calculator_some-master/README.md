# calculator_some
14.4.2015

Calculator app using NSExpression:
Log-14.4.2015
- DRY for number buttons
- Logic in class CalculatorController
