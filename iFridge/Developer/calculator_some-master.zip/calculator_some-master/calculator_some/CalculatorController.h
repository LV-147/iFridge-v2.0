//
//  CalculatorController.h
//  calculator_some
//
//  Created by Taras Pasichnyk on 4/14/15.
//  Copyright (c) 2015 Taras Pasichnyk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CalculatorController : NSObject

+ (NSMutableString*) getFormattedString: (NSString*) string;
+ (NSNumber*) getRusltUsing: (NSString*) equation;
+ (NSString*) getValidEquation: (NSString*) string;
@end
