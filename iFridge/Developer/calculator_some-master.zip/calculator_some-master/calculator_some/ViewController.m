//
//  ViewController.m
//  calculator_some
//
//  Created by Taras Pasichnyk on 4/10/15.
//  Copyright (c) 2015 Taras Pasichnyk. All rights reserved.
//

#import "ViewController.h"
#import "CalculatorController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *myTextField; //expression text field
@property (nonatomic) NSString *stroke; //test
@property (nonatomic) NSString *textContent; //test
@property (nonatomic) NSMutableArray *myArray; //test

//@property (nonatomic) NSNumber* result; //stores expression result
//@property (nonatomic) NSExpression* expression; //stores parsed expression
@property (nonatomic) NSDictionary *object; //test????? Check.
@property (nonatomic) NSRegularExpression *regex;
@property (nonatomic) NSTextCheckingResult *match;
//@property (nonatomic) NSError *error;
@end



NSString * newString;

int check1 = 1; //checks input of multiply operator
int check2 = 1;
int check3 = 1;
int check4 = 1;
int check5 = 1;
int check6 = 1;
int scenario[3] = {1, 2, 3}; //used to change scenarios in switch statement
int it = 0; //iterator

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _myTextField.text = @""; //initializing values
    _myArray = [[NSMutableArray alloc] init];
    _textContent = @"";
    //_result = 0;
    _myTextField.enabled = NO;

    _regex = [NSRegularExpression regularExpressionWithPattern:@"[-+]?([0-9]*\\.[0-9]+|[0-9]+)" options:0 error:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)addNumberByTag:(UIButton *)sender {
    _myTextField.text =  [_myTextField.text stringByAppendingString:
                     [NSString stringWithFormat:@"%ld", (long)sender.tag]];
}

- (IBAction)addSeparatorDot:(UIButton *)sender {
    //if(check1 % 2 != 0){
        _myTextField.text =  [_myTextField.text stringByAppendingString: [NSString stringWithFormat:@"."]];

}

- (IBAction)removeLastSymbol:(UIButton *)sender {
    _myTextField.text = [_myTextField.text substringToIndex:[_myTextField.text length] - 1];
}

- (IBAction)addSumSymbol:(UIButton *)sender {
        _myTextField.text =  [_myTextField.text stringByAppendingString:
                              [NSString stringWithFormat:@"+"]];
}

- (IBAction)addMinusSymbol:(UIButton *)sender {
    //if(check3 % 2 != 0){
        _myTextField.text =  [_myTextField.text stringByAppendingString:
                              [NSString stringWithFormat:@"-"]];

}

- (IBAction)addMultiplySymbol:(UIButton *)sender {
       _myTextField.text =  [_myTextField.text stringByAppendingString:
                        [NSString stringWithFormat:@"*"]];
}

- (IBAction)addDivideSymbol:(UIButton *)sender {
   // if(check5 % 2 != 0){
        _myTextField.text =  [_myTextField.text stringByAppendingString:
                              [NSString stringWithFormat:@"/"]];
   // }else{
    //    _myTextField.text = [_myTextField.text substringToIndex:[_myTextField.text length] - 1];
    //}
    //check5++;
}

- (IBAction)clearTextFiles:(id)sender {
    self.myTextField.text = @"";
    _textContent = @"";
}

- (IBAction)getResultsAction:(UIButton *)sender {
    @try {
        _myTextField.text =  [_myTextField.text stringByAppendingString:
                              [NSString stringWithFormat:@"=%@", [CalculatorController getRusltUsing:_myTextField.text]]];
    }
    @catch (NSException *exception) {
        NSLog(@"Uncaught exception: %@", exception.description);
        NSLog(@"Stack trace: %@", [exception callStackSymbols]);
        _myTextField.text = @"Syntax Error";
    }
    
    //NSLog(@"%@", _expression);
    //NSLog(@"%@", formattedString);
    //NSLog(@"%@", _result);
}

@end
