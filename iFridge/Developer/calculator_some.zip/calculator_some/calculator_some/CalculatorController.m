//
//  CalculatorController.m
//  calculator_some
//
//  Created by Taras Pasichnyk on 4/14/15.
//  Copyright (c) 2015 Taras Pasichnyk. All rights reserved.
//

#import "CalculatorController.h"

@implementation CalculatorController

//function to format input string to work properly with float values 2/3 = 0.6666~
+ (NSMutableString *)getFormattedString:(NSString *)formula{
    NSString *str = formula;
    NSInteger c = 0;
    for(int i=0; i<[str length]; i++)
    {
        
        if([[NSString stringWithFormat:@"%c",[str characterAtIndex:i]] isEqualToString:@"+"] ||
           [[NSString stringWithFormat:@"%c",[str characterAtIndex:i]] isEqualToString:@"-"] ||
           [[NSString stringWithFormat:@"%c",[str characterAtIndex:i]] isEqualToString:@"/"] ||
           [[NSString stringWithFormat:@"%c",[str characterAtIndex:i]] isEqualToString:@"*"])
        {
            if([str length] > i+1)
            {
                if([[NSString stringWithFormat:@"%c",[str characterAtIndex:i+1]] isEqualToString:@"."])
                {
                    formula = [formula stringByReplacingCharactersInRange:NSMakeRange(i+1+c, 1) withString:@"0."];
                    c++;
                }
            }
        }
    }
    
    // Now we will convert all numbers in float
    
    NSString *aString;
    float aFloat;
    NSMutableString *formattedString = [[NSMutableString alloc]init];
    
    NSScanner *theScanner = [NSScanner scannerWithString:formula];
    while ([theScanner isAtEnd] == NO)
    {
        
        if([theScanner scanFloat:&aFloat])
        {
            [formattedString appendString:[NSString stringWithFormat:@"%f",aFloat]];
        }
        
        if([theScanner scanUpToCharactersFromSet:[NSCharacterSet decimalDigitCharacterSet] intoString:&aString])
        {
            [formattedString appendString:aString];
        }
    }
    return formattedString;
}

@end
