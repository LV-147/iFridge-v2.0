//
//  ViewController.h
//  calculator_some
//
//  Created by Taras Pasichnyk on 4/10/15.
//  Copyright (c) 2015 Taras Pasichnyk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end

