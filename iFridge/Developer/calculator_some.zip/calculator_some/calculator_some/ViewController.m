//
//  ViewController.m
//  calculator_some
//
//  Created by Taras Pasichnyk on 4/10/15.
//  Copyright (c) 2015 Taras Pasichnyk. All rights reserved.
//

#import "ViewController.h"
#import "CalculatorController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *myTextField; //expression text field
@property (nonatomic) NSString* stroke; //test
@property (nonatomic) NSString* textContent; //test
@property (nonatomic) NSMutableArray* myArray; //test

@property (nonatomic) NSNumber* result; //stores expression result
@property (nonatomic) NSExpression* expression; //stores parsed expression
@property (nonatomic) NSDictionary* object; //test????? Check.
@end

//---Primary
//1. [To Do] Validate equation using regular expressions.
//2. [Done] Push logic into classes.
//3. [Done] Don't Repeat Yourself (Dry)

//---Secondary
//1. [Done] Predict multiply operators input using active and inactive button
//2. [Done] Implement math parser for 2/3 = 0.0000000 => 2/3 = 0.6666~
//3. [Not Needed] Create result box
//4. [To Do] Create operation story (make a database or use some of the patterns like singletone or factory - To Do
//5. [To Do] Sin, Cos, tg, ctg, sqrt

NSString * newString;

int check1 = 1; //checks input of multiply operator
int check2 = 1;
int check3 = 1;
int check4 = 1;
int check5 = 1;
int check6 = 1;
int scenario[3] = {1, 2, 3}; //used to change scenarios in switch statement
int it = 0; //iterator

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _myTextField.text = @""; //initializing values
    _myArray = [[NSMutableArray alloc] init];
    _textContent = @"";
    _result = 0;
    _myTextField.enabled = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)addNumberByTag:(UIButton *)sender {
    _myTextField.text =  [_myTextField.text stringByAppendingString:
                          [NSString stringWithFormat:@"%ld", (long)sender.tag]];
}

- (IBAction)addSeparatorDot:(UIButton *)sender {
    //if(check1 % 2 != 0){
        _myTextField.text =  [_myTextField.text stringByAppendingString:
                          [NSString stringWithFormat:@"."]];
    //}else{
    //    _myTextField.text = [_myTextField.text substringToIndex:[_myTextField.text length] - 1];
    //}
    //check1++;
}

- (IBAction)addSumSymbol:(UIButton *)sender {
    //if(check2 % 2 != 0){
        _myTextField.text =  [_myTextField.text stringByAppendingString:
                              [NSString stringWithFormat:@"+"]];
    //}else{
    //    _myTextField.text = [_myTextField.text substringToIndex:[_myTextField.text length] - 1];
    //}
    //check2++;
}

- (IBAction)addMinusSymbol:(UIButton *)sender {
    //if(check3 % 2 != 0){
        _myTextField.text =  [_myTextField.text stringByAppendingString:
                              [NSString stringWithFormat:@"-"]];
    //}else{
    //    _myTextField.text = [_myTextField.text substringToIndex:[_myTextField.text length] - 1];
    //}
    //check3++;
}

- (IBAction)addMultiplySymbol:(UIButton *)sender {
    //if(check4 % 2 != 0){
       _myTextField.text =  [_myTextField.text stringByAppendingString:
                        [NSString stringWithFormat:@"*"]];
   // }else{
    //    _myTextField.text = [_myTextField.text substringToIndex:[_myTextField.text length] - 1];
    //}
    //check4++;
    
    //switch checks whether user wants to multiply of to power the number (one click - multiply, double click - power). The third click cancels multiply and power.
    
    //switch (scenario[it]) {
    //    case 1:
    //        _myTextField.text =  [_myTextField.text stringByAppendingString:
     //                             [NSString stringWithFormat:@"*"]];
     //       break;
     //   case 2:
      //      _myTextField.text =  [_myTextField.text stringByAppendingString:
      //                            [NSString stringWithFormat:@"*"]];
      //      break;
      //  case 3:
      //      _myTextField.text = [_myTextField.text substringToIndex:[_myTextField.text length] - 2];
      //      break;
    //}
   // it++;
    //if(it == 3)
     //   it = 0;
}

- (IBAction)addDivideSymbol:(UIButton *)sender {
   // if(check5 % 2 != 0){
        _myTextField.text =  [_myTextField.text stringByAppendingString:
                              [NSString stringWithFormat:@"/"]];
   // }else{
    //    _myTextField.text = [_myTextField.text substringToIndex:[_myTextField.text length] - 1];
    //}
    //check5++;
}

- (IBAction)clearTextFiles:(id)sender {
    self.myTextField.text = @"";
}

- (IBAction)getResultsAction:(UIButton *)sender {
    
    _textContent = _myTextField.text;
    NSString *formattedString = [CalculatorController getFormattedString:_textContent];
    _expression = [NSExpression expressionWithFormat:formattedString];
    _result = [_expression expressionValueWithObject:nil context:nil];
    _myTextField.text =  [_myTextField.text stringByAppendingString:
                          [NSString stringWithFormat:@"=%@", _result]];
    NSLog(@"%@", _expression);
    NSLog(@"%@", formattedString);
    NSLog(@"%@", _result);
}

@end
